let cart = JSON.parse(localStorage.getItem("cart")) || [];

// Add product to cart
function addToCart(name, price) {
    const item = cart.find(product => product.name === name);
    if (item) {
        item.quantity += 1;
    } else {
        cart.push({ name, price, quantity: 1 });
    }
    localStorage.setItem("cart", JSON.stringify(cart));
    alert(`${name} added to cart!`);
}

// Render cart items on cart.html
function renderCart() {
    const container = document.getElementById("cart-items");
    const totalElem = document.getElementById("cart-total");
    container.innerHTML = "";

    let total = 0;
    if (cart.length === 0) {
        container.innerHTML = "<p>Your cart is empty.</p>";
        totalElem.textContent = "Total: $0.00";
        return;
    }

    cart.forEach((item, index) => {
        total += item.price * item.quantity;
        container.innerHTML += `
            <div class="cart-item">
                <span>${item.name} x ${item.quantity}</span>
                <span>$${(item.price * item.quantity).toFixed(2)}</span>
                <button onclick="removeItem(${index})">Remove</button>
            </div>`;
    });

    totalElem.textContent = "Total: $" + total.toFixed(2);
}

// Remove an item from cart
function removeItem(index) {
    cart.splice(index, 1);
    localStorage.setItem("cart", JSON.stringify(cart));
    renderCart();
}
