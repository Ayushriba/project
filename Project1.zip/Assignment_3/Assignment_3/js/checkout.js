function submitCheckout() {
    const name = document.getElementById("name").value.trim();
    const email = document.getElementById("email").value.trim();
    const address = document.getElementById("address").value.trim();

    if (!name || !email || !address) {
        alert("Please fill out all fields before placing your order.");
        return;
    }

    // Optionally, save order data or simulate confirmation
    alert("Order placed successfully!");

    // Clear cart and redirect to thank you page
    localStorage.removeItem("cart");
    window.location.href = "thankyou.html";
}
