// Initialize and add the map
function initMap() {
    // The location of the company
    const companyLocation = { lat: -25.344, lng: 131.036 };
    // The map, centered at the company location
    const map = new google.maps.Map(document.getElementById("map"), {
        zoom: 4,
        center: companyLocation,
    });
    // The marker, positioned at the company location
    const marker = new google.maps.Marker({
        position: companyLocation,
        map: map,
    });
}

// Form validation
document.addEventListener('DOMContentLoaded', function() {
    const form = document.querySelector('form');
    form.addEventListener('submit', function(event) {
        event.preventDefault();
        const name = document.getElementById('name').value;
        const email = document.getElementById('email').value;
        const message = document.getElementById('message').value;

        if (name === '' || email === '' || message === '') {
            alert('Please fill in all fields.');
        } else {
            alert('Thank you for your message!');
            form.reset();
        }
    });
});